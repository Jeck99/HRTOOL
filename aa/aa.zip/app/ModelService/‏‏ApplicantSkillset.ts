export class ApplicantSkillset
{
        constructor(ApplicantId: number , skillid: number) {
        this.ApplicantId = ApplicantId;
        this.SkillId = skillid;     

    }
    Id :number;
    ApplicantId :number;
    SkillId :number;
}