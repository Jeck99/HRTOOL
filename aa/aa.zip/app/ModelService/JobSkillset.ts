export class JobSkillset
{
        constructor(jobid: number , skillid: number) {
        this.JobId = jobid;
        this.SkillId = skillid;     

    }
    Id :number;
    JobId :number;
    SkillId :number;
}