        export class MailBuild
        {
            Body : string;
            Subject : string;
            To : string;
            constructor() { 
                this.Body = "";                   
                this.Subject = "";                   
                this.To = "";                   
            }
        }