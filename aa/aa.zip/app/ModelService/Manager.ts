﻿ export class Manager
    {
        Id :number;
        UserName:string;
        Email: string;
        Password: string;
        Role: string ;
    }