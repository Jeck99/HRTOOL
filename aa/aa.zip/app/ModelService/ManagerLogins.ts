﻿export class ManagerLogins
    {
        Id:number;
        UserId:number;
        SessionId: string;
    }
