export class JobRecruiter {
    constructor(jobid: number, recruiterId: number) {
        this.JobId = jobid;
        this.RecruiterId = recruiterId;

    }
    Id: number;
    JobId: number;
    RecruiterId: number;
}