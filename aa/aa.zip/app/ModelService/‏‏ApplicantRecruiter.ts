export class ApplicantRecruiter {

    constructor(applicantId: number, recruiterId: number) {
        this.ApplicantId = applicantId;
        this.RecruiterId = recruiterId;

    }
    Id: number;
    ApplicantId: number;
    RecruiterId: number;
}