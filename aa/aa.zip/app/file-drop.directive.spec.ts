import { FileDropDirective } from './file-drop.directive';

describe('FileDropDirective', () => {
  it('should create an instance', () => {
    const directive = new FileDropDirective();
    expect(directive).toBeTruthy();
  });
});
