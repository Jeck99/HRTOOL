
export const FireConfig = 
{
    apiKey: "AIzaSyCZHAQHkv5aeJzAj6HdMRcyj2NSJAHOHaw",
    authDomain: "at-and-t-project-cd4d4.firebaseapp.com",
    databaseURL: "https://at-and-t-project-cd4d4.firebaseio.com",
    projectId: "at-and-t-project-cd4d4",
    storageBucket: "at-and-t-project-cd4d4.appspot.com",
    messagingSenderId: "595994921346"
}


